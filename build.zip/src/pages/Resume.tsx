import { useEffect } from "react";

function Resume() {
    return(
        <>
            <section className="banner"></section>
        </>
    )
}

export default Resume