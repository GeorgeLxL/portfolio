import { useEffect } from "react";

function About() {
    return(
        <>
            <section className="banner"></section>
        </>
    )
}

export default About