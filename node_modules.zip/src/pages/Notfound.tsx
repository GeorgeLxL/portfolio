function Notfound() {
    return(
        <>
            <section className="banner"></section>
        </>
    )
}

export default Notfound