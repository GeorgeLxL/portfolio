import { useEffect } from "react";

function Portfolio() {
    return(
        <>
            <section className="banner"></section>
        </>
    )
}

export default Portfolio