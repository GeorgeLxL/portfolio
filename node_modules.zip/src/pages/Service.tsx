import { useEffect } from "react";

function Service() {
    return(
        <>
            <section className="banner"></section>
        </>
    )
}

export default Service